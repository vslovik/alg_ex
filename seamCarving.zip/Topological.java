/**
 * Topological order for Grid DAG
 */
public class Topological {

    private int W, H;
    private boolean[] marked;
    private Stack<Integer> reversePost;

    public Topological(int W, int H) {
        this.W = W;
        this.H = H;
        reversePost = new Stack<Integer>();
        marked = new boolean[W * H];
        for (int x = 0; x < W; x++)
            if (!marked[x]) dfs(x, 0);
    }

    private void dfs(int x, int y) {
        int n;
        int N = y * W + x;
        marked[N] = true;

        if (y + 1 < H) {
            for (int k = x - 1; k <= x + 1; k++) {
                n = (y + 1) * W + k;
                if (k >= 0 && k < W && !marked[n]) {
                    dfs(k, y + 1);
                }
            }
        }

        reversePost.push(N);
    }

    public Iterable<Integer> order() {
        return reversePost;
    }

    /**
     * Tests this <tt>Picture</tt> data type. Reads a picture specified by the command-line argument,
     * and shows it in a window on the screen.
     */
    public static void main(String[] args) {
        int W = 3;
        int H = 7;
        int x, y;
        Topological t = new Topological(W, H);
        for (Integer N : t.order()) {
            if (N < W) {
                x = N;
                y = 0;
            } else {
                y = N / W;
                x = N % W;
            }

            System.out.printf("%d---%d\n", x, y);
        }
    }
}
